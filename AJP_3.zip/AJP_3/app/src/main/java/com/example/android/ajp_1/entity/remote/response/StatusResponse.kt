package com.example.android.ajp_1.entity.remote.response

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}