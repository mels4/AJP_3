package com.example.android.ajp_1.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}