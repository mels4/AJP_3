package com.example.android.ajp_1.entity


data class TvShowEntity (
    var tvShowId: String,
    var title: String,
    var decription: String,
    var imagePath: String,
    var user_score: Double,
    var ImgPathBgr: String,
    var genre: String,
    var duration: String,
    var share_link: String
)